from ikan import *
from ular import *
from burung import *


i = Ikan("Daging", "Laut", "Telur", "Laut", "Besar",)
u = Ular("daging", "bertelur", "tidak berbisa")
b = Burung("jagung", "darat", "bertelur", "melengkung", "warna warni",)

i.info_Ikan()
u.cetak_Ular()
b.info_burung()