from Gempa import *

gempa1 = Gempa('Banten', 1.2)
gempa1.dampak()
gempa1 = Gempa('palu', 6.1)
gempa1.dampak()
gempa1 = Gempa('cianjur', 5.6)
gempa1.dampak()
gempa1 = Gempa('jayapura', 3.3)
gempa1.dampak()
gempa1 = Gempa('garut', 4.0)
gempa1.dampak()