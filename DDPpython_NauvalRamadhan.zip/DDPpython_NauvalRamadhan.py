print("nama:Nauval Ramadhan")
print("nim: 0110124171") 
print("rombel: SI07")   
print("asdos:Bang jaya")    